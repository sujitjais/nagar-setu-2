// backend/utils/otp.js
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const { query } = require('../config/db');

// ── Generate a 6-digit OTP ───────────────────────────────────────────────────
function generateOTP() {
  return String(crypto.randomInt(100000, 999999));
}

// ── Email transporter ────────────────────────────────────────────────────────
function createTransporter() {
  return nodemailer.createTransporter({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.SMTP_PORT || '587'),
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });
}

// ── OTP Email Template ───────────────────────────────────────────────────────
function buildOtpEmail(otp, purpose, name) {
  const purposeLabel = {
    login: 'Sign In',
    register: 'Account Registration',
    reset: 'Password Reset',
  }[purpose] || 'Verification';

  return {
    subject: `NagarSeva — Your OTP for ${purposeLabel}: ${otp}`,
    html: `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"/>
  <style>
    body{font-family:'Segoe UI',Arial,sans-serif;background:#F0F2F5;margin:0;padding:0}
    .wrap{max-width:520px;margin:32px auto;background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,60,.12)}
    .header{background:linear-gradient(135deg,#002060,#003380);padding:28px 32px;text-align:center}
    .logo-box{display:inline-block;background:linear-gradient(145deg,#FF6600,#FF8800);border-radius:8px;padding:10px 16px;margin-bottom:12px}
    .logo-text{color:#fff;font-size:20px;font-weight:700;letter-spacing:.5px}
    .header h2{color:#fff;font-size:15px;font-weight:400;margin:0;opacity:.8}
    .body{padding:32px}
    .greeting{font-size:15px;color:#1A2540;margin-bottom:16px}
    .otp-wrap{text-align:center;margin:28px 0}
    .otp-box{display:inline-block;background:linear-gradient(135deg,#EEF3FF,#F8FAFF);border:2px solid #003380;border-radius:10px;padding:20px 40px}
    .otp-label{font-size:11px;color:#6B7A99;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px}
    .otp-digits{font-size:42px;font-weight:700;color:#003380;letter-spacing:10px;font-family:monospace}
    .expiry{text-align:center;font-size:13px;color:#6B7A99;margin-top:4px}
    .purpose-badge{display:inline-block;background:#FFF3EC;color:#CC5200;border:1px solid #fad7a0;border-radius:4px;padding:3px 12px;font-size:12px;font-weight:600;margin-bottom:20px}
    .warning{background:#FFFBEB;border-left:3px solid #D97706;padding:12px 16px;border-radius:0 6px 6px 0;font-size:12px;color:#78350F;margin-top:20px}
    .footer{background:#F0F2F5;padding:20px 32px;text-align:center;font-size:11px;color:#94A3B8;border-top:1px solid #E2E8F0}
    .tricolor{height:3px;background:linear-gradient(90deg,#FF6600 33%,#fff 33%,#fff 66%,#138808 66%)}
  </style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <div class="logo-box"><span class="logo-text">🏛️ NagarSeva</span></div>
    <h2>Smart Civic Issue Management Platform</h2>
  </div>
  <div class="tricolor"></div>
  <div class="body">
    <p class="greeting">Dear ${name || 'Citizen'},</p>
    <p style="font-size:13px;color:#3A4A6B">You requested a one-time password for:</p>
    <div style="text-align:center;margin:8px 0"><span class="purpose-badge">📋 ${purposeLabel}</span></div>
    <div class="otp-wrap">
      <div class="otp-box">
        <div class="otp-label">Your OTP</div>
        <div class="otp-digits">${otp}</div>
      </div>
    </div>
    <p class="expiry">⏳ Valid for <strong>${process.env.OTP_EXPIRY_MINUTES || 10} minutes</strong></p>
    <div class="warning">
      🔒 Never share this OTP with anyone. NagarSeva officials will never ask for your OTP.
      If you did not request this, please ignore this email.
    </div>
  </div>
  <div class="footer">
    <p>NagarSeva — Government of India Civic Platform</p>
    <p style="margin-top:4px">© 2026 NagarSeva. All rights reserved.</p>
  </div>
</div>
</body>
</html>`,
    text: `Your NagarSeva OTP for ${purposeLabel} is: ${otp}\nValid for ${process.env.OTP_EXPIRY_MINUTES || 10} minutes.\nDo not share this with anyone.`,
  };
}

// ── Send OTP ─────────────────────────────────────────────────────────────────
async function sendOTP(email, purpose, name = '') {
  const otp = generateOTP();
  const expiryMinutes = parseInt(process.env.OTP_EXPIRY_MINUTES || '10');
  const expiresAt = new Date(Date.now() + expiryMinutes * 60 * 1000);

  // Invalidate old OTPs for this email+purpose
  await query(
    `UPDATE otp_tokens SET used = TRUE WHERE email = $1 AND purpose = $2 AND used = FALSE`,
    [email, purpose]
  );

  // Save new OTP
  await query(
    `INSERT INTO otp_tokens (email, otp, purpose, expires_at) VALUES ($1, $2, $3, $4)`,
    [email, otp, purpose, expiresAt]
  );

  // Dev mode: just log to console
  if (process.env.OTP_DEV_MODE === 'true') {
    console.log(`\n🔐 OTP [DEV MODE] ─────────────────────`);
    console.log(`   Email  : ${email}`);
    console.log(`   Purpose: ${purpose}`);
    console.log(`   OTP    : ${otp}`);
    console.log(`   Expires: ${expiresAt.toISOString()}`);
    console.log(`──────────────────────────────────────\n`);
    return { success: true, devOtp: otp };
  }

  // Production: send email
  const transporter = createTransporter();
  const emailContent = buildOtpEmail(otp, purpose, name);

  await transporter.sendMail({
    from: process.env.EMAIL_FROM || 'NagarSeva <noreply@nagarseva.gov.in>',
    to: email,
    subject: emailContent.subject,
    html: emailContent.html,
    text: emailContent.text,
  });

  return { success: true };
}

// ── Verify OTP ───────────────────────────────────────────────────────────────
async function verifyOTP(email, otp, purpose) {
  const maxAttempts = parseInt(process.env.OTP_MAX_ATTEMPTS || '3');

  // Find latest valid OTP
  const result = await query(
    `SELECT id, otp, expires_at, attempts, used
     FROM otp_tokens
     WHERE email = $1 AND purpose = $2 AND used = FALSE
     ORDER BY created_at DESC
     LIMIT 1`,
    [email, purpose]
  );

  if (result.rows.length === 0) {
    return { valid: false, error: 'No OTP found. Please request a new one.' };
  }

  const record = result.rows[0];

  // Check expiry
  if (new Date() > new Date(record.expires_at)) {
    await query(`UPDATE otp_tokens SET used = TRUE WHERE id = $1`, [record.id]);
    return { valid: false, error: 'OTP has expired. Please request a new one.' };
  }

  // Check max attempts
  if (record.attempts >= maxAttempts) {
    await query(`UPDATE otp_tokens SET used = TRUE WHERE id = $1`, [record.id]);
    return { valid: false, error: 'Too many incorrect attempts. Please request a new OTP.' };
  }

  // Check OTP value
  if (record.otp !== otp) {
    await query(
      `UPDATE otp_tokens SET attempts = attempts + 1 WHERE id = $1`,
      [record.id]
    );
    const remaining = maxAttempts - record.attempts - 1;
    return {
      valid: false,
      error: `Incorrect OTP. ${remaining} attempt${remaining !== 1 ? 's' : ''} remaining.`,
    };
  }

  // Mark used
  await query(`UPDATE otp_tokens SET used = TRUE WHERE id = $1`, [record.id]);

  return { valid: true };
}

module.exports = { sendOTP, verifyOTP, generateOTP };
