// backend/utils/jwt.js
const jwt = require('jsonwebtoken');

function signToken(payload) {
  return jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });
}

function signRefreshToken(payload) {
  return jwt.sign(payload, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '30d',
  });
}

function verifyToken(token) {
  try {
    return { valid: true, payload: jwt.verify(token, process.env.JWT_SECRET) };
  } catch (err) {
    return { valid: false, error: err.message };
  }
}

function verifyRefreshToken(token) {
  try {
    return { valid: true, payload: jwt.verify(token, process.env.JWT_REFRESH_SECRET) };
  } catch (err) {
    return { valid: false, error: err.message };
  }
}

module.exports = { signToken, signRefreshToken, verifyToken, verifyRefreshToken };
