// backend/routes/issues.js
const express = require('express');
const router = express.Router();
const { body, query: qVal, validationResult, param } = require('express-validator');
const { query, transaction } = require('../config/db');
const { authenticate, requireRole, optionalAuth } = require('../middleware/auth');

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// GET /api/issues  — Public feed with filters
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.get('/', optionalAuth, async (req, res) => {
  try {
    const {
      category, severity, status, ward, city,
      page = 1, limit = 20, sort = 'created_at',
      order = 'desc', search,
    } = req.query;

    const conditions = ["i.status != 'rejected'"];
    const values = [];
    let idx = 1;

    if (category) { conditions.push(`i.category = $${idx++}`); values.push(category); }
    if (severity) { conditions.push(`i.severity = $${idx++}`); values.push(severity); }
    if (status) { conditions.push(`i.status = $${idx++}`); values.push(status); }
    if (ward) { conditions.push(`i.ward ILIKE $${idx++}`); values.push(`%${ward}%`); }
    if (city) { conditions.push(`i.city ILIKE $${idx++}`); values.push(`%${city}%`); }
    if (search) {
      conditions.push(`(i.title ILIKE $${idx} OR i.description ILIKE $${idx} OR i.address ILIKE $${idx})`);
      values.push(`%${search}%`);
      idx++;
    }

    const validSorts = ['created_at', 'votes', 'priority_score', 'updated_at'];
    const sortField = validSorts.includes(sort) ? sort : 'created_at';
    const sortOrder = order === 'asc' ? 'ASC' : 'DESC';

    const offset = (Math.max(1, parseInt(page)) - 1) * Math.min(100, parseInt(limit));
    const limitVal = Math.min(100, parseInt(limit));

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const result = await query(
      `SELECT i.id, i.ref_number, i.title, i.category, i.severity, i.status,
              i.address, i.landmark, i.ward, i.city, i.latitude, i.longitude,
              i.votes, i.priority_score, i.created_at, i.updated_at,
              i.estimated_resolution, i.resolved_at,
              u.name AS reporter_name,
              d.name AS department_name, d.code AS dept_code,
              (SELECT url FROM issue_media WHERE issue_id = i.id LIMIT 1) AS thumbnail
       FROM issues i
       LEFT JOIN users u ON i.reported_by = u.id
       LEFT JOIN departments d ON i.department_id = d.id
       ${where}
       ORDER BY i.${sortField} ${sortOrder}
       LIMIT $${idx++} OFFSET $${idx++}`,
      [...values, limitVal, offset]
    );

    const countResult = await query(
      `SELECT COUNT(*) FROM issues i ${where}`,
      values
    );

    return res.json({
      success: true,
      issues: result.rows,
      total: parseInt(countResult.rows[0].count),
      page: parseInt(page),
      limit: limitVal,
    });
  } catch (err) {
    console.error('GET /issues error:', err);
    return res.status(500).json({ success: false, message: 'Failed to fetch issues.' });
  }
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// GET /api/issues/:id  — Single issue with activity + media
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.get('/:id', optionalAuth, async (req, res) => {
  try {
    const { id } = req.params;

    const result = await query(
      `SELECT i.*,
              u.name AS reporter_name, u.email AS reporter_email,
              d.name AS department_name, d.code AS dept_code, d.email AS dept_email,
              o.name AS assigned_officer_name
       FROM issues i
       LEFT JOIN users u ON i.reported_by = u.id
       LEFT JOIN departments d ON i.department_id = d.id
       LEFT JOIN users o ON i.assigned_to = o.id
       WHERE i.id = $1 OR i.ref_number = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Issue not found.' });
    }

    const issue = result.rows[0];

    // Increment views
    await query(`UPDATE issues SET views = views + 1 WHERE id = $1`, [issue.id]);

    // Fetch media
    const media = await query(
      `SELECT id, url, media_type, mime_type, created_at FROM issue_media WHERE issue_id = $1 ORDER BY created_at`,
      [issue.id]
    );

    // Fetch activity (public only unless officer/admin)
    const isPrivileged = req.user && ['officer', 'admin', 'superadmin'].includes(req.user.role);
    const activity = await query(
      `SELECT a.*, u.name AS actor_display
       FROM issue_activity a
       LEFT JOIN users u ON a.actor_id = u.id
       WHERE a.issue_id = $1 ${!isPrivileged ? 'AND a.is_public = TRUE' : ''}
       ORDER BY a.created_at ASC`,
      [issue.id]
    );

    // Fetch comments
    const comments = await query(
      `SELECT c.id, c.comment, c.is_official, c.created_at,
              u.name AS author_name, u.role AS author_role
       FROM issue_comments c
       JOIN users u ON c.author_id = u.id
       WHERE c.issue_id = $1 AND c.is_hidden = FALSE
       ORDER BY c.created_at ASC`,
      [issue.id]
    );

    return res.json({
      success: true,
      issue: { ...issue, media: media.rows, activity: activity.rows, comments: comments.rows },
    });
  } catch (err) {
    console.error('GET /issues/:id error:', err);
    return res.status(500).json({ success: false, message: 'Failed to fetch issue.' });
  }
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// POST /api/issues  — Create issue (authenticated)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.post(
  '/',
  authenticate,
  [
    body('title').trim().isLength({ min: 10, max: 500 }).withMessage('Title must be 10-500 chars.'),
    body('category').isIn(['roads', 'water', 'lighting', 'drainage', 'waste', 'parks', 'other']),
    body('severity').optional().isIn(['low', 'medium', 'high', 'critical']),
    body('description').optional().trim().isLength({ max: 5000 }),
    body('address').optional().trim(),
    body('latitude').optional().isFloat({ min: -90, max: 90 }),
    body('longitude').optional().isFloat({ min: -180, max: 180 }),
    body('ward').optional().trim(),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const {
      title, category, severity = 'medium', description,
      address, landmark, ward, latitude, longitude,
    } = req.body;

    try {
      // Auto-assign department based on category
      const deptMap = {
        roads: 'ROADS', water: 'WATER', lighting: 'LIGHT',
        drainage: 'DRAIN', waste: 'WASTE', parks: 'PARKS', other: 'GENERAL',
      };
      const deptCode = deptMap[category] || 'GENERAL';
      const dept = await query(`SELECT id FROM departments WHERE code = $1`, [deptCode]);
      const deptId = dept.rows[0]?.id || null;

      // Simple AI priority score (can be replaced with real ML)
      const sevScore = { low: 20, medium: 45, high: 70, critical: 95 };
      const priorityScore = sevScore[severity] || 50;

      const result = await transaction(async (client) => {
        const issue = await client.query(
          `INSERT INTO issues (
            title, description, category, severity, status,
            address, landmark, ward, latitude, longitude,
            reported_by, department_id, priority_score, ref_number
          ) VALUES ($1,$2,$3,$4,'open',$5,$6,$7,$8,$9,$10,$11,$12,'')
          RETURNING *`,
          [
            title, description || null, category, severity,
            address || null, landmark || null, ward || req.user.ward || null,
            latitude || null, longitude || null,
            req.user.id, deptId, priorityScore,
          ]
        );

        const newIssue = issue.rows[0];

        // Log activity
        await client.query(
          `INSERT INTO issue_activity (issue_id, actor_id, actor_name, action, note, is_public)
           VALUES ($1,$2,$3,'created',$4,TRUE)`,
          [newIssue.id, req.user.id, req.user.name, `Issue reported by ${req.user.name}`]
        );

        return newIssue;
      });

      // Create notification for department if assigned
      if (deptId) {
        await query(
          `INSERT INTO notifications (user_id, issue_id, title, message, type)
           SELECT u.id, $1, $2, $3, 'info'
           FROM users u WHERE u.role IN ('officer','admin') LIMIT 5`,
          [result.id, `New Issue: ${title}`, `A new ${severity} priority ${category} issue has been reported.`]
        );
      }

      return res.status(201).json({
        success: true,
        message: 'Issue submitted successfully.',
        issue: result,
      });
    } catch (err) {
      console.error('POST /issues error:', err);
      return res.status(500).json({ success: false, message: 'Failed to submit issue.' });
    }
  }
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// PATCH /api/issues/:id/status  — Officer/Admin updates status
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.patch(
  '/:id/status',
  authenticate,
  requireRole('officer', 'admin', 'superadmin'),
  [
    body('status').isIn(['open', 'verified', 'assigned', 'in_progress', 'resolved', 'rejected', 'duplicate']),
    body('note').optional().trim().isLength({ max: 1000 }),
    body('assignTo').optional().isUUID(),
    body('resolutionNote').optional().trim(),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { id } = req.params;
    const { status, note, assignTo, resolutionNote, estimatedResolution } = req.body;

    try {
      const issueResult = await query(`SELECT * FROM issues WHERE id = $1`, [id]);
      if (issueResult.rows.length === 0) {
        return res.status(404).json({ success: false, message: 'Issue not found.' });
      }

      const oldIssue = issueResult.rows[0];

      const updates = ['status = $1', 'updated_at = NOW()'];
      const values = [status];
      let idx = 2;

      if (assignTo) { updates.push(`assigned_to = $${idx++}`); values.push(assignTo); }
      if (status === 'resolved') {
        updates.push(`resolved_at = NOW()`);
        if (resolutionNote) { updates.push(`resolution_note = $${idx++}`); values.push(resolutionNote); }
      }
      if (estimatedResolution) { updates.push(`estimated_resolution = $${idx++}`); values.push(estimatedResolution); }

      values.push(id);
      await query(`UPDATE issues SET ${updates.join(', ')} WHERE id = $${idx}`, values);

      // Log activity
      await query(
        `INSERT INTO issue_activity (issue_id, actor_id, actor_name, action, old_value, new_value, note, is_public)
         VALUES ($1,$2,$3,'status_changed',$4,$5,$6,TRUE)`,
        [id, req.user.id, req.user.name, oldIssue.status, status, note || `Status changed to ${status}`]
      );

      // Notify reporter
      if (oldIssue.reported_by) {
        await query(
          `INSERT INTO notifications (user_id, issue_id, title, message, type)
           VALUES ($1,$2,$3,$4,$5)`,
          [
            oldIssue.reported_by, id,
            `Your issue status updated: ${oldIssue.ref_number}`,
            `Status changed from ${oldIssue.status} to ${status}. ${note || ''}`,
            status === 'resolved' ? 'success' : 'update',
          ]
        );
      }

      return res.json({ success: true, message: `Issue status updated to ${status}.` });
    } catch (err) {
      console.error('PATCH /issues/:id/status error:', err);
      return res.status(500).json({ success: false, message: 'Failed to update status.' });
    }
  }
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// POST /api/issues/:id/vote
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.post('/:id/vote', authenticate, async (req, res) => {
  const { id } = req.params;
  try {
    // Check existing vote
    const existing = await query(
      `SELECT id FROM issue_votes WHERE issue_id = $1 AND user_id = $2`,
      [id, req.user.id]
    );

    if (existing.rows.length > 0) {
      // Remove vote (toggle)
      await query(`DELETE FROM issue_votes WHERE issue_id = $1 AND user_id = $2`, [id, req.user.id]);
      await query(`UPDATE issues SET votes = GREATEST(0, votes - 1) WHERE id = $1`, [id]);
      return res.json({ success: true, voted: false, message: 'Vote removed.' });
    }

    // Add vote
    await query(`INSERT INTO issue_votes (issue_id, user_id) VALUES ($1, $2)`, [id, req.user.id]);
    await query(`UPDATE issues SET votes = votes + 1 WHERE id = $1`, [id]);

    return res.json({ success: true, voted: true, message: 'Vote added.' });
  } catch (err) {
    console.error('vote error:', err);
    return res.status(500).json({ success: false, message: 'Vote failed.' });
  }
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// POST /api/issues/:id/rate  — Citizen rates resolved issue
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.post(
  '/:id/rate',
  authenticate,
  [
    body('rating').isInt({ min: 1, max: 5 }),
    body('feedback').optional().trim().isLength({ max: 1000 }),
  ],
  async (req, res) => {
    const { id } = req.params;
    const { rating, feedback } = req.body;

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    try {
      const issue = await query(
        `SELECT id, status, reported_by FROM issues WHERE id = $1`,
        [id]
      );

      if (issue.rows.length === 0) {
        return res.status(404).json({ success: false, message: 'Issue not found.' });
      }

      if (issue.rows[0].status !== 'resolved') {
        return res.status(400).json({ success: false, message: 'Can only rate resolved issues.' });
      }

      if (issue.rows[0].reported_by !== req.user.id) {
        return res.status(403).json({ success: false, message: 'Only the reporter can rate.' });
      }

      await query(
        `UPDATE issues SET citizen_rating = $1, citizen_feedback = $2 WHERE id = $3`,
        [rating, feedback || null, id]
      );

      await query(
        `INSERT INTO issue_activity (issue_id, actor_id, actor_name, action, new_value, is_public)
         VALUES ($1,$2,$3,'rated',$4,TRUE)`,
        [id, req.user.id, req.user.name, `${rating}/5 stars`]
      );

      return res.json({ success: true, message: 'Thank you for your feedback!' });
    } catch (err) {
      console.error('rate error:', err);
      return res.status(500).json({ success: false, message: 'Rating failed.' });
    }
  }
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// POST /api/issues/:id/comments
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.post(
  '/:id/comments',
  authenticate,
  [body('comment').trim().isLength({ min: 2, max: 2000 })],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { id } = req.params;
    const { comment } = req.body;
    const isOfficial = ['officer', 'admin', 'superadmin'].includes(req.user.role);

    try {
      const result = await query(
        `INSERT INTO issue_comments (issue_id, author_id, comment, is_official)
         VALUES ($1,$2,$3,$4) RETURNING *`,
        [id, req.user.id, comment, isOfficial]
      );

      await query(
        `INSERT INTO issue_activity (issue_id, actor_id, actor_name, action, note, is_public)
         VALUES ($1,$2,$3,'commented',$4,TRUE)`,
        [id, req.user.id, req.user.name, comment.substring(0, 100)]
      );

      return res.status(201).json({ success: true, comment: result.rows[0] });
    } catch (err) {
      console.error('comment error:', err);
      return res.status(500).json({ success: false, message: 'Failed to post comment.' });
    }
  }
);

module.exports = router;
