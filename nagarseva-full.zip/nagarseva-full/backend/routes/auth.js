// backend/routes/auth.js
const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const rateLimit = require('express-rate-limit');

const { query, transaction } = require('../config/db');
const { sendOTP, verifyOTP } = require('../utils/otp');
const { signToken, signRefreshToken, verifyRefreshToken } = require('../utils/jwt');
const { authenticate } = require('../middleware/auth');

// ── OTP rate limiter (5 per 15 min per IP) ───────────────────────────────────
const otpLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: parseInt(process.env.OTP_RATE_LIMIT_MAX || '5'),
  message: { success: false, message: 'Too many OTP requests. Please wait 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// POST /api/auth/send-otp
// Sends OTP for login OR registration
// Body: { email, purpose: 'login'|'register'|'reset', name? }
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.post(
  '/send-otp',
  otpLimiter,
  [
    body('email').isEmail().normalizeEmail().withMessage('Valid email required.'),
    body('purpose').isIn(['login', 'register', 'reset']).withMessage('Invalid purpose.'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { email, purpose, name } = req.body;

    try {
      // For login: user must exist
      if (purpose === 'login') {
        const user = await query(`SELECT id, name FROM users WHERE email = $1 AND is_active = TRUE`, [email]);
        if (user.rows.length === 0) {
          // Security: don't reveal if user exists — send generic message
          return res.json({
            success: true,
            message: 'If an account exists, an OTP has been sent.',
          });
        }
        const { devOtp } = await sendOTP(email, 'login', user.rows[0].name);
        return res.json({
          success: true,
          message: 'OTP sent to your email address.',
          ...(devOtp ? { devOtp } : {}), // Only in dev mode
        });
      }

      // For register: user must NOT exist
      if (purpose === 'register') {
        const existing = await query(`SELECT id FROM users WHERE email = $1`, [email]);
        if (existing.rows.length > 0) {
          return res.status(409).json({
            success: false,
            message: 'An account with this email already exists. Please log in.',
          });
        }
        const { devOtp } = await sendOTP(email, 'register', name || '');
        return res.json({
          success: true,
          message: 'OTP sent. Please check your email.',
          ...(devOtp ? { devOtp } : {}),
        });
      }

      // For reset: user must exist
      if (purpose === 'reset') {
        const user = await query(`SELECT id, name FROM users WHERE email = $1`, [email]);
        if (user.rows.length === 0) {
          return res.json({ success: true, message: 'If an account exists, an OTP has been sent.' });
        }
        const { devOtp } = await sendOTP(email, 'reset', user.rows[0].name);
        return res.json({
          success: true,
          message: 'OTP sent to your email.',
          ...(devOtp ? { devOtp } : {}),
        });
      }
    } catch (err) {
      console.error('send-otp error:', err);
      return res.status(500).json({ success: false, message: 'Failed to send OTP. Please try again.' });
    }
  }
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// POST /api/auth/verify-otp  (Login)
// Body: { email, otp }
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.post(
  '/verify-otp',
  [
    body('email').isEmail().normalizeEmail(),
    body('otp').isLength({ min: 6, max: 6 }).isNumeric().withMessage('OTP must be 6 digits.'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { email, otp } = req.body;

    try {
      const result = await verifyOTP(email, otp, 'login');
      if (!result.valid) {
        return res.status(400).json({ success: false, message: result.error });
      }

      // Fetch user
      const userResult = await query(
        `SELECT id, name, email, phone, role, ward, zone, city, is_verified, avatar_url
         FROM users WHERE email = $1 AND is_active = TRUE`,
        [email]
      );

      if (userResult.rows.length === 0) {
        return res.status(404).json({ success: false, message: 'User not found.' });
      }

      const user = userResult.rows[0];

      // Mark verified if not already
      if (!user.is_verified) {
        await query(`UPDATE users SET is_verified = TRUE WHERE id = $1`, [user.id]);
        user.is_verified = true;
      }

      const token = signToken({ userId: user.id, role: user.role });
      const refreshToken = signRefreshToken({ userId: user.id });

      return res.json({
        success: true,
        message: 'Login successful.',
        token,
        refreshToken,
        user,
      });
    } catch (err) {
      console.error('verify-otp error:', err);
      return res.status(500).json({ success: false, message: 'Verification failed.' });
    }
  }
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// POST /api/auth/register
// Creates account then verifies OTP
// Body: { name, email, phone, otp, ward?, city? }
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.post(
  '/register',
  [
    body('name').trim().isLength({ min: 2, max: 200 }).withMessage('Name must be 2-200 chars.'),
    body('email').isEmail().normalizeEmail(),
    body('otp').isLength({ min: 6, max: 6 }).isNumeric(),
    body('phone').optional().isMobilePhone().withMessage('Invalid phone number.'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { name, email, otp, phone, ward, city } = req.body;

    try {
      // Verify OTP first
      const otpResult = await verifyOTP(email, otp, 'register');
      if (!otpResult.valid) {
        return res.status(400).json({ success: false, message: otpResult.error });
      }

      // Check if user already exists
      const existing = await query(`SELECT id FROM users WHERE email = $1`, [email]);
      if (existing.rows.length > 0) {
        return res.status(409).json({ success: false, message: 'Account already exists.' });
      }

      // Create user
      const newUser = await query(
        `INSERT INTO users (name, email, phone, role, ward, city, is_verified)
         VALUES ($1, $2, $3, 'citizen', $4, $5, TRUE)
         RETURNING id, name, email, phone, role, ward, city, is_verified, created_at`,
        [name, email, phone || null, ward || null, city || 'Lucknow']
      );

      const user = newUser.rows[0];
      const token = signToken({ userId: user.id, role: user.role });
      const refreshToken = signRefreshToken({ userId: user.id });

      return res.status(201).json({
        success: true,
        message: 'Account created successfully. Welcome to NagarSeva!',
        token,
        refreshToken,
        user,
      });
    } catch (err) {
      console.error('register error:', err);
      return res.status(500).json({ success: false, message: 'Registration failed.' });
    }
  }
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// POST /api/auth/admin/send-otp
// Admin-specific OTP (only for admin/officer emails)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.post(
  '/admin/send-otp',
  otpLimiter,
  [body('email').isEmail().normalizeEmail()],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { email } = req.body;

    try {
      const user = await query(
        `SELECT id, name, role FROM users WHERE email = $1 AND is_active = TRUE AND role IN ('admin','officer','superadmin')`,
        [email]
      );

      if (user.rows.length === 0) {
        // Security: same message regardless
        return res.json({ success: true, message: 'If authorized, an OTP has been sent.' });
      }

      const { devOtp } = await sendOTP(email, 'login', user.rows[0].name);
      return res.json({
        success: true,
        message: 'Admin OTP sent.',
        role: user.rows[0].role,
        ...(devOtp ? { devOtp } : {}),
      });
    } catch (err) {
      console.error('admin/send-otp error:', err);
      return res.status(500).json({ success: false, message: 'Failed to send OTP.' });
    }
  }
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// POST /api/auth/admin/verify-otp
// Admin login via OTP
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.post(
  '/admin/verify-otp',
  [
    body('email').isEmail().normalizeEmail(),
    body('otp').isLength({ min: 6, max: 6 }).isNumeric(),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { email, otp } = req.body;

    try {
      const otpResult = await verifyOTP(email, otp, 'login');
      if (!otpResult.valid) {
        return res.status(400).json({ success: false, message: otpResult.error });
      }

      const userResult = await query(
        `SELECT id, name, email, phone, role, ward, zone, city, is_verified
         FROM users WHERE email = $1 AND is_active = TRUE AND role IN ('admin','officer','superadmin')`,
        [email]
      );

      if (userResult.rows.length === 0) {
        return res.status(403).json({ success: false, message: 'Access denied. Admin role required.' });
      }

      const user = userResult.rows[0];
      const token = signToken({ userId: user.id, role: user.role });
      const refreshToken = signRefreshToken({ userId: user.id });

      return res.json({
        success: true,
        message: `Welcome back, ${user.name}. Admin access granted.`,
        token,
        refreshToken,
        user,
      });
    } catch (err) {
      console.error('admin/verify-otp error:', err);
      return res.status(500).json({ success: false, message: 'Verification failed.' });
    }
  }
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// POST /api/auth/refresh
// Refresh access token
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.post('/refresh', async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) {
    return res.status(400).json({ success: false, message: 'Refresh token required.' });
  }

  const { valid, payload } = verifyRefreshToken(refreshToken);
  if (!valid) {
    return res.status(401).json({ success: false, message: 'Invalid refresh token.' });
  }

  try {
    const userResult = await query(
      `SELECT id, role FROM users WHERE id = $1 AND is_active = TRUE`,
      [payload.userId]
    );

    if (userResult.rows.length === 0) {
      return res.status(401).json({ success: false, message: 'User not found.' });
    }

    const user = userResult.rows[0];
    const token = signToken({ userId: user.id, role: user.role });

    return res.json({ success: true, token });
  } catch (err) {
    console.error('refresh error:', err);
    return res.status(500).json({ success: false, message: 'Token refresh failed.' });
  }
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// GET /api/auth/me
// Get current user profile
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.get('/me', authenticate, async (req, res) => {
  try {
    // Fetch with extra details
    const result = await query(
      `SELECT u.id, u.name, u.email, u.phone, u.role, u.ward, u.zone, u.city, u.state,
              u.is_verified, u.avatar_url, u.created_at,
              COUNT(i.id) AS total_reports,
              COUNT(i.id) FILTER (WHERE i.status = 'resolved') AS resolved_reports
       FROM users u
       LEFT JOIN issues i ON i.reported_by = u.id
       WHERE u.id = $1
       GROUP BY u.id`,
      [req.user.id]
    );

    return res.json({ success: true, user: result.rows[0] });
  } catch (err) {
    console.error('me error:', err);
    return res.status(500).json({ success: false, message: 'Failed to fetch profile.' });
  }
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// PATCH /api/auth/profile
// Update profile
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.patch(
  '/profile',
  authenticate,
  [
    body('name').optional().trim().isLength({ min: 2, max: 200 }),
    body('phone').optional().isMobilePhone(),
    body('ward').optional().trim(),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { name, phone, ward, city } = req.body;
    const updates = [];
    const values = [];
    let i = 1;

    if (name) { updates.push(`name = $${i++}`); values.push(name); }
    if (phone) { updates.push(`phone = $${i++}`); values.push(phone); }
    if (ward !== undefined) { updates.push(`ward = $${i++}`); values.push(ward); }
    if (city) { updates.push(`city = $${i++}`); values.push(city); }

    if (updates.length === 0) {
      return res.status(400).json({ success: false, message: 'No fields to update.' });
    }

    values.push(req.user.id);

    try {
      await query(`UPDATE users SET ${updates.join(', ')} WHERE id = $${i}`, values);
      return res.json({ success: true, message: 'Profile updated.' });
    } catch (err) {
      console.error('profile update error:', err);
      return res.status(500).json({ success: false, message: 'Update failed.' });
    }
  }
);

module.exports = router;
