// backend/routes/admin.js
const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const { query } = require('../config/db');
const { authenticate, requireRole } = require('../middleware/auth');

// All admin routes require auth + admin/superadmin role
router.use(authenticate, requireRole('admin', 'superadmin', 'officer'));

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// GET /api/admin/stats  — Dashboard stats
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.get('/stats', async (req, res) => {
  try {
    const stats = await query(`SELECT * FROM admin_stats`);
    const byCategory = await query(
      `SELECT category, COUNT(*) as count, 
              COUNT(*) FILTER (WHERE status='resolved') as resolved
       FROM issues GROUP BY category ORDER BY count DESC`
    );
    const bySeverity = await query(
      `SELECT severity, COUNT(*) as count FROM issues GROUP BY severity ORDER BY count DESC`
    );
    const topIssues = await query(
      `SELECT ref_number, title, severity, status, votes, priority_score, created_at
       FROM issues WHERE status NOT IN ('resolved','rejected')
       ORDER BY priority_score DESC, votes DESC LIMIT 10`
    );
    const recentActivity = await query(
      `SELECT a.action, a.note, a.created_at, a.actor_name,
              i.ref_number, i.title
       FROM issue_activity a
       JOIN issues i ON a.issue_id = i.id
       ORDER BY a.created_at DESC LIMIT 20`
    );

    return res.json({
      success: true,
      stats: stats.rows[0],
      byCategory: byCategory.rows,
      bySeverity: bySeverity.rows,
      topIssues: topIssues.rows,
      recentActivity: recentActivity.rows,
    });
  } catch (err) {
    console.error('admin/stats error:', err);
    return res.status(500).json({ success: false, message: 'Failed to fetch stats.' });
  }
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// GET /api/admin/issues  — All issues with full detail
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.get('/issues', async (req, res) => {
  try {
    const { status, category, severity, department, page = 1, limit = 50 } = req.query;
    const conditions = [];
    const values = [];
    let idx = 1;

    if (status) { conditions.push(`i.status = $${idx++}`); values.push(status); }
    if (category) { conditions.push(`i.category = $${idx++}`); values.push(category); }
    if (severity) { conditions.push(`i.severity = $${idx++}`); values.push(severity); }
    if (department) { conditions.push(`d.code = $${idx++}`); values.push(department); }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const offset = (Math.max(1, parseInt(page)) - 1) * parseInt(limit);

    values.push(Math.min(100, parseInt(limit)));
    values.push(offset);

    const result = await query(
      `SELECT i.id, i.ref_number, i.title, i.category, i.severity, i.status,
              i.address, i.ward, i.city, i.votes, i.priority_score,
              i.created_at, i.updated_at, i.estimated_resolution,
              u.name AS reporter_name, u.email AS reporter_email,
              d.name AS department_name, o.name AS assigned_to_name
       FROM issues i
       LEFT JOIN users u ON i.reported_by = u.id
       LEFT JOIN departments d ON i.department_id = d.id
       LEFT JOIN users o ON i.assigned_to = o.id
       ${where}
       ORDER BY i.priority_score DESC, i.created_at DESC
       LIMIT $${idx++} OFFSET $${idx++}`,
      values
    );

    return res.json({ success: true, issues: result.rows });
  } catch (err) {
    console.error('admin/issues error:', err);
    return res.status(500).json({ success: false, message: 'Failed to fetch issues.' });
  }
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// GET /api/admin/users  — User management (superadmin/admin only)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.get('/users', requireRole('admin', 'superadmin'), async (req, res) => {
  try {
    const { role, page = 1, limit = 50, search } = req.query;
    const conditions = [];
    const values = [];
    let idx = 1;

    if (role) { conditions.push(`u.role = $${idx++}`); values.push(role); }
    if (search) {
      conditions.push(`(u.name ILIKE $${idx} OR u.email ILIKE $${idx})`);
      values.push(`%${search}%`);
      idx++;
    }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const offset = (Math.max(1, parseInt(page)) - 1) * parseInt(limit);
    values.push(Math.min(100, parseInt(limit)));
    values.push(offset);

    const result = await query(
      `SELECT u.id, u.name, u.email, u.phone, u.role, u.ward, u.city,
              u.is_verified, u.is_active, u.created_at,
              COUNT(i.id) AS total_issues
       FROM users u
       LEFT JOIN issues i ON i.reported_by = u.id
       ${where}
       GROUP BY u.id
       ORDER BY u.created_at DESC
       LIMIT $${idx++} OFFSET $${idx++}`,
      values
    );

    return res.json({ success: true, users: result.rows });
  } catch (err) {
    console.error('admin/users error:', err);
    return res.status(500).json({ success: false, message: 'Failed to fetch users.' });
  }
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// PATCH /api/admin/users/:id  — Update user role/status
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.patch(
  '/users/:id',
  requireRole('admin', 'superadmin'),
  [
    body('role').optional().isIn(['citizen', 'officer', 'admin', 'superadmin']),
    body('is_active').optional().isBoolean(),
    body('ward').optional().trim(),
    body('department_id').optional().isUUID(),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { id } = req.params;
    const { role, is_active, ward } = req.body;

    const updates = [];
    const values = [];
    let idx = 1;

    if (role !== undefined) { updates.push(`role = $${idx++}`); values.push(role); }
    if (is_active !== undefined) { updates.push(`is_active = $${idx++}`); values.push(is_active); }
    if (ward !== undefined) { updates.push(`ward = $${idx++}`); values.push(ward); }

    if (updates.length === 0) {
      return res.status(400).json({ success: false, message: 'Nothing to update.' });
    }

    values.push(id);

    try {
      await query(`UPDATE users SET ${updates.join(', ')} WHERE id = $${idx}`, values);
      return res.json({ success: true, message: 'User updated.' });
    } catch (err) {
      console.error('admin/users/:id PATCH error:', err);
      return res.status(500).json({ success: false, message: 'Update failed.' });
    }
  }
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// GET /api/admin/departments  — List departments
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.get('/departments', async (req, res) => {
  try {
    const result = await query(
      `SELECT d.*,
              COUNT(i.id) AS total_issues,
              COUNT(i.id) FILTER (WHERE i.status = 'resolved') AS resolved_issues,
              COUNT(i.id) FILTER (WHERE i.status IN ('open','assigned','in_progress')) AS open_issues
       FROM departments d
       LEFT JOIN issues i ON i.department_id = d.id
       GROUP BY d.id
       ORDER BY d.name`
    );
    return res.json({ success: true, departments: result.rows });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Failed to fetch departments.' });
  }
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// GET /api/admin/notifications
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
router.get('/notifications', async (req, res) => {
  try {
    const result = await query(
      `SELECT n.*, i.ref_number, i.title AS issue_title
       FROM notifications n
       LEFT JOIN issues i ON n.issue_id = i.id
       WHERE n.user_id = $1
       ORDER BY n.created_at DESC LIMIT 50`,
      [req.user.id]
    );
    await query(`UPDATE notifications SET is_read = TRUE WHERE user_id = $1 AND is_read = FALSE`, [req.user.id]);
    return res.json({ success: true, notifications: result.rows });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Failed to fetch notifications.' });
  }
});

module.exports = router;
