// backend/middleware/auth.js
const { verifyToken } = require('../utils/jwt');
const { query } = require('../config/db');

// Attach user to request if JWT is valid
async function authenticate(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, message: 'No token provided.' });
  }

  const token = header.slice(7);
  const { valid, payload, error } = verifyToken(token);

  if (!valid) {
    return res.status(401).json({ success: false, message: 'Invalid or expired token.' });
  }

  // Fetch fresh user from DB
  try {
    const result = await query(
      `SELECT id, name, email, phone, role, ward, zone, city, is_verified, is_active, avatar_url
       FROM users WHERE id = $1 AND is_active = TRUE`,
      [payload.userId]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ success: false, message: 'User not found or deactivated.' });
    }

    req.user = result.rows[0];
    next();
  } catch (err) {
    console.error('Auth middleware error:', err);
    return res.status(500).json({ success: false, message: 'Authentication error.' });
  }
}

// Require specific roles
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Not authenticated.' });
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Access denied. Required role: ${roles.join(' or ')}.`,
      });
    }
    next();
  };
}

// Optional auth — attaches user if token present but doesn't fail
async function optionalAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    req.user = null;
    return next();
  }

  const token = header.slice(7);
  const { valid, payload } = verifyToken(token);

  if (!valid) {
    req.user = null;
    return next();
  }

  try {
    const result = await query(
      `SELECT id, name, email, phone, role, ward, zone, city, is_verified, is_active
       FROM users WHERE id = $1 AND is_active = TRUE`,
      [payload.userId]
    );
    req.user = result.rows[0] || null;
  } catch {
    req.user = null;
  }
  next();
}

module.exports = { authenticate, requireRole, optionalAuth };
