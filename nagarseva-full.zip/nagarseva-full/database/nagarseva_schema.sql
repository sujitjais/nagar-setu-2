-- ============================================================
-- NagarSeva — Complete PostgreSQL Database Schema
-- Run this on your Neon/Supabase/Railway PostgreSQL instance
-- ============================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";  -- For geospatial queries (optional, remove if not available)

-- ─── USERS TABLE ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(200) NOT NULL,
  email         VARCHAR(255) UNIQUE NOT NULL,
  phone         VARCHAR(20),
  role          VARCHAR(20) NOT NULL DEFAULT 'citizen' CHECK (role IN ('citizen','officer','admin','superadmin')),
  ward          VARCHAR(100),
  zone          VARCHAR(100),
  city          VARCHAR(100) DEFAULT 'Lucknow',
  state         VARCHAR(100) DEFAULT 'Uttar Pradesh',
  is_verified   BOOLEAN DEFAULT FALSE,
  is_active     BOOLEAN DEFAULT TRUE,
  avatar_url    TEXT,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ─── OTP TABLE ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS otp_tokens (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email       VARCHAR(255) NOT NULL,
  otp         VARCHAR(6) NOT NULL,
  purpose     VARCHAR(30) NOT NULL DEFAULT 'login' CHECK (purpose IN ('login','register','reset')),
  expires_at  TIMESTAMPTZ NOT NULL,
  used        BOOLEAN DEFAULT FALSE,
  attempts    INT DEFAULT 0,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast OTP lookup
CREATE INDEX IF NOT EXISTS idx_otp_email_purpose ON otp_tokens(email, purpose);
CREATE INDEX IF NOT EXISTS idx_otp_expires ON otp_tokens(expires_at);

-- ─── DEPARTMENTS TABLE ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS departments (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(200) NOT NULL,
  code          VARCHAR(50) UNIQUE NOT NULL,
  description   TEXT,
  head_officer  UUID REFERENCES users(id),
  email         VARCHAR(255),
  phone         VARCHAR(20),
  is_active     BOOLEAN DEFAULT TRUE,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ─── ISSUES TABLE ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS issues (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ref_number      VARCHAR(20) UNIQUE NOT NULL,  -- e.g. NS-20261847
  title           VARCHAR(500) NOT NULL,
  description     TEXT,
  category        VARCHAR(50) NOT NULL CHECK (category IN (
                    'roads','water','lighting','drainage','waste','parks','other'
                  )),
  severity        VARCHAR(20) NOT NULL DEFAULT 'medium' CHECK (severity IN (
                    'low','medium','high','critical'
                  )),
  status          VARCHAR(30) NOT NULL DEFAULT 'open' CHECK (status IN (
                    'open','verified','assigned','in_progress','resolved','rejected','duplicate'
                  )),
  priority_score  INT DEFAULT 50,  -- 0-100 AI-computed score

  -- Location
  address         TEXT,
  landmark        TEXT,
  ward            VARCHAR(100),
  zone            VARCHAR(100),
  city            VARCHAR(100) DEFAULT 'Lucknow',
  state           VARCHAR(100) DEFAULT 'Uttar Pradesh',
  latitude        DECIMAL(10,8),
  longitude       DECIMAL(11,8),
  location_accuracy DECIMAL(8,2),  -- GPS accuracy in meters

  -- Relations
  reported_by     UUID REFERENCES users(id) ON DELETE SET NULL,
  assigned_to     UUID REFERENCES users(id) ON DELETE SET NULL,
  department_id   UUID REFERENCES departments(id) ON DELETE SET NULL,
  duplicate_of    UUID REFERENCES issues(id) ON DELETE SET NULL,

  -- Meta
  votes           INT DEFAULT 0,
  views           INT DEFAULT 0,
  estimated_resolution DATE,
  resolved_at     TIMESTAMPTZ,
  resolution_note TEXT,
  citizen_rating  INT CHECK (citizen_rating BETWEEN 1 AND 5),
  citizen_feedback TEXT,

  -- Timestamps
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_issues_status ON issues(status);
CREATE INDEX IF NOT EXISTS idx_issues_category ON issues(category);
CREATE INDEX IF NOT EXISTS idx_issues_severity ON issues(severity);
CREATE INDEX IF NOT EXISTS idx_issues_reported_by ON issues(reported_by);
CREATE INDEX IF NOT EXISTS idx_issues_department ON issues(department_id);
CREATE INDEX IF NOT EXISTS idx_issues_created ON issues(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_issues_location ON issues(city, ward);
-- Geospatial index (requires postgis)
-- CREATE INDEX IF NOT EXISTS idx_issues_geo ON issues USING GIST(ST_MakePoint(longitude, latitude));

-- ─── ISSUE MEDIA TABLE ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS issue_media (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  issue_id    UUID NOT NULL REFERENCES issues(id) ON DELETE CASCADE,
  url         TEXT NOT NULL,
  s3_key      TEXT,
  media_type  VARCHAR(20) DEFAULT 'image' CHECK (media_type IN ('image','video','audio')),
  mime_type   VARCHAR(100),
  file_size   INT,  -- bytes
  uploaded_by UUID REFERENCES users(id),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_media_issue ON issue_media(issue_id);

-- ─── ISSUE TIMELINE / ACTIVITY LOG ──────────────────────────
CREATE TABLE IF NOT EXISTS issue_activity (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  issue_id    UUID NOT NULL REFERENCES issues(id) ON DELETE CASCADE,
  actor_id    UUID REFERENCES users(id),
  actor_name  VARCHAR(200),  -- Denormalized for display
  action      VARCHAR(50) NOT NULL CHECK (action IN (
                'created','verified','assigned','status_changed',
                'commented','media_added','escalated','resolved','rejected','rated'
              )),
  old_value   TEXT,
  new_value   TEXT,
  note        TEXT,
  is_public   BOOLEAN DEFAULT TRUE,  -- Visible to citizen?
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_activity_issue ON issue_activity(issue_id);
CREATE INDEX IF NOT EXISTS idx_activity_created ON issue_activity(created_at DESC);

-- ─── VOTES TABLE ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS issue_votes (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  issue_id    UUID NOT NULL REFERENCES issues(id) ON DELETE CASCADE,
  user_id     UUID REFERENCES users(id),
  ip_address  INET,  -- Fallback for anonymous votes
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(issue_id, user_id),        -- One vote per user per issue
  UNIQUE(issue_id, ip_address)      -- One vote per IP (anonymous)
);

CREATE INDEX IF NOT EXISTS idx_votes_issue ON issue_votes(issue_id);

-- ─── NOTIFICATIONS TABLE ────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  issue_id    UUID REFERENCES issues(id) ON DELETE CASCADE,
  title       VARCHAR(300) NOT NULL,
  message     TEXT NOT NULL,
  type        VARCHAR(30) DEFAULT 'info' CHECK (type IN ('info','success','warning','error','update')),
  is_read     BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, is_read);

-- ─── COMMENTS TABLE ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS issue_comments (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  issue_id    UUID NOT NULL REFERENCES issues(id) ON DELETE CASCADE,
  author_id   UUID NOT NULL REFERENCES users(id),
  comment     TEXT NOT NULL,
  is_official BOOLEAN DEFAULT FALSE,  -- Authority comment?
  is_hidden   BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_comments_issue ON issue_comments(issue_id);

-- ─── SMS LOG TABLE ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sms_log (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  phone       VARCHAR(20) NOT NULL,
  message     TEXT NOT NULL,
  direction   VARCHAR(10) DEFAULT 'out' CHECK (direction IN ('in','out')),
  issue_id    UUID REFERENCES issues(id),
  status      VARCHAR(20) DEFAULT 'sent',
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ─── SEED DEPARTMENTS ───────────────────────────────────────
INSERT INTO departments (name, code, description, email) VALUES
  ('Roads & Infrastructure', 'ROADS', 'Handles potholes, road damage, footpath repairs', 'roads@nagarseva.gov.in'),
  ('Jal Nigam (Water)', 'WATER', 'Water supply, pipeline repairs, leakages', 'water@nagarseva.gov.in'),
  ('LESA (Electricity)', 'LIGHT', 'Street lighting, electrical infrastructure', 'lesa@nagarseva.gov.in'),
  ('Drainage & Sewerage', 'DRAIN', 'Stormwater drains, sewerage blockages, flooding', 'drain@nagarseva.gov.in'),
  ('Waste Management', 'WASTE', 'Garbage collection, illegal dumping, sanitation', 'waste@nagarseva.gov.in'),
  ('Parks & Horticulture', 'PARKS', 'Public parks, trees, green spaces', 'parks@nagarseva.gov.in'),
  ('General Services', 'GENERAL', 'Miscellaneous civic issues', 'general@nagarseva.gov.in')
ON CONFLICT (code) DO NOTHING;

-- ─── SEED ADMIN USER ────────────────────────────────────────
-- Password: admin123 (bcrypt hash — change immediately in production!)
INSERT INTO users (name, email, phone, role, city, is_verified) VALUES
  ('NagarSeva Admin', 'admin@nagarseva.gov.in', '+919876543210', 'admin', 'Lucknow', TRUE)
ON CONFLICT (email) DO NOTHING;

-- ─── AUTO-UPDATE updated_at TRIGGER ─────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_issues_updated_at
  BEFORE UPDATE ON issues
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ─── AUTO-INCREMENT REFERENCE NUMBER ────────────────────────
CREATE SEQUENCE IF NOT EXISTS issue_ref_seq START 10000;

CREATE OR REPLACE FUNCTION generate_issue_ref()
RETURNS TRIGGER AS $$
BEGIN
  NEW.ref_number = 'NS-' || EXTRACT(YEAR FROM NOW())::TEXT || LPAD(nextval('issue_ref_seq')::TEXT, 4, '0');
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER set_issue_ref
  BEFORE INSERT ON issues
  FOR EACH ROW
  WHEN (NEW.ref_number IS NULL OR NEW.ref_number = '')
  EXECUTE FUNCTION generate_issue_ref();

-- ─── VIEW: PUBLIC ISSUE FEED ─────────────────────────────────
CREATE OR REPLACE VIEW public_issues AS
SELECT
  i.id, i.ref_number, i.title, i.category, i.severity, i.status,
  i.address, i.landmark, i.ward, i.city, i.latitude, i.longitude,
  i.votes, i.priority_score, i.created_at, i.updated_at,
  i.estimated_resolution, i.resolved_at,
  u.name AS reporter_name,
  d.name AS department_name, d.code AS dept_code,
  (SELECT url FROM issue_media WHERE issue_id = i.id LIMIT 1) AS thumbnail
FROM issues i
LEFT JOIN users u ON i.reported_by = u.id
LEFT JOIN departments d ON i.department_id = d.id
WHERE i.status != 'rejected';

-- ─── VIEW: ADMIN STATS ──────────────────────────────────────
CREATE OR REPLACE VIEW admin_stats AS
SELECT
  COUNT(*) FILTER (WHERE status = 'open') AS open_count,
  COUNT(*) FILTER (WHERE status = 'in_progress') AS in_progress_count,
  COUNT(*) FILTER (WHERE status = 'resolved') AS resolved_count,
  COUNT(*) FILTER (WHERE severity = 'critical') AS critical_count,
  COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '24 hours') AS new_today,
  COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '30 days') AS new_this_month,
  ROUND(AVG(EXTRACT(EPOCH FROM (resolved_at - created_at))/86400.0) FILTER (WHERE status = 'resolved'), 1) AS avg_resolution_days,
  ROUND(COUNT(*) FILTER (WHERE status = 'resolved') * 100.0 / NULLIF(COUNT(*), 0), 1) AS resolution_rate
FROM issues;

-- ─── CLEAN EXPIRED OTPs (run periodically) ──────────────────
-- You can schedule this as a cron job or call it manually:
-- DELETE FROM otp_tokens WHERE expires_at < NOW();

COMMENT ON TABLE issues IS 'Core civic issues reported by citizens';
COMMENT ON TABLE users IS 'Citizens, officers, and administrators';
COMMENT ON TABLE otp_tokens IS 'One-time passwords for authentication';
COMMENT ON TABLE issue_activity IS 'Audit trail for all issue state changes';

-- Done!
SELECT 'NagarSeva database schema installed successfully!' AS message;
