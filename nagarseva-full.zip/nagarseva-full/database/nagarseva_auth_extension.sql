-- ============================================================
-- NagarSeva — Extended Database Schema (Auth-Enhanced)
-- Run AFTER the base nagarseva_schema.sql
-- Or run this standalone (it includes all the base tables too)
-- ============================================================

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── USERS (already in base schema — shown here for reference) ───────────────
-- The base schema has all required columns. No changes needed.

-- ─── SESSION / REFRESH TOKENS TABLE ────────────────────────────────────────
-- Tracks refresh tokens for secure multi-device auth
CREATE TABLE IF NOT EXISTS refresh_tokens (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash    VARCHAR(255) NOT NULL UNIQUE, -- Store hash, not raw token
  device_info   TEXT,                          -- Browser/device fingerprint
  ip_address    INET,
  is_revoked    BOOLEAN DEFAULT FALSE,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  expires_at    TIMESTAMPTZ NOT NULL,
  last_used_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_refresh_tokens_user ON refresh_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_refresh_tokens_hash ON refresh_tokens(token_hash);

-- ─── LOGIN AUDIT LOG ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS auth_audit_log (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID REFERENCES users(id),
  email       VARCHAR(255),
  action      VARCHAR(30) NOT NULL CHECK (action IN (
                'otp_sent','otp_verified','login','logout','register',
                'otp_failed','token_refreshed','profile_updated'
              )),
  ip_address  INET,
  user_agent  TEXT,
  success     BOOLEAN DEFAULT TRUE,
  note        TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_auth_audit_user ON auth_audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_auth_audit_created ON auth_audit_log(created_at DESC);

-- ─── ENHANCED OTP TABLE (clean up old entries periodically) ─────────────────
-- Already in base schema. Add this index if not present:
CREATE INDEX IF NOT EXISTS idx_otp_created ON otp_tokens(created_at DESC);

-- ─── ADMIN NOTIFICATIONS VIEW ───────────────────────────────────────────────
CREATE OR REPLACE VIEW unread_notifications_count AS
SELECT
  user_id,
  COUNT(*) FILTER (WHERE is_read = FALSE) AS unread_count,
  COUNT(*) AS total_count
FROM notifications
GROUP BY user_id;

-- ─── USER ACTIVITY SUMMARY VIEW ─────────────────────────────────────────────
CREATE OR REPLACE VIEW user_activity_summary AS
SELECT
  u.id,
  u.name,
  u.email,
  u.role,
  u.city,
  u.is_verified,
  u.created_at,
  COUNT(DISTINCT i.id) AS total_reports,
  COUNT(DISTINCT i.id) FILTER (WHERE i.status = 'resolved') AS resolved_count,
  COUNT(DISTINCT i.id) FILTER (WHERE i.status = 'open') AS open_count,
  MAX(i.created_at) AS last_report_date
FROM users u
LEFT JOIN issues i ON i.reported_by = u.id
GROUP BY u.id;

-- ─── DEPARTMENT PERFORMANCE VIEW ────────────────────────────────────────────
CREATE OR REPLACE VIEW department_performance AS
SELECT
  d.id,
  d.name,
  d.code,
  d.email,
  COUNT(i.id) AS total_assigned,
  COUNT(i.id) FILTER (WHERE i.status = 'resolved') AS resolved,
  COUNT(i.id) FILTER (WHERE i.status IN ('open','assigned','in_progress')) AS pending,
  COUNT(i.id) FILTER (WHERE i.severity = 'critical') AS critical_count,
  ROUND(
    COUNT(i.id) FILTER (WHERE i.status = 'resolved') * 100.0 / NULLIF(COUNT(i.id), 0),
    1
  ) AS resolution_rate_pct,
  ROUND(
    AVG(EXTRACT(EPOCH FROM (i.resolved_at - i.created_at))/86400.0)
    FILTER (WHERE i.status = 'resolved'),
    1
  ) AS avg_resolution_days
FROM departments d
LEFT JOIN issues i ON i.department_id = d.id
GROUP BY d.id;

-- ─── SEED ADDITIONAL ADMIN USERS ────────────────────────────────────────────
-- Test officer account (OTP will be sent to email in production)
INSERT INTO users (name, email, phone, role, city, ward, is_verified) VALUES
  ('Field Officer — Lucknow', 'officer@nagarseva.gov.in', '+919876543211', 'officer', 'Lucknow', 'Ward 12', TRUE),
  ('City Supervisor', 'supervisor@nagarseva.gov.in', '+919876543212', 'admin', 'Lucknow', NULL, TRUE)
ON CONFLICT (email) DO NOTHING;

-- ─── FUNCTION: Clean expired OTPs ───────────────────────────────────────────
CREATE OR REPLACE FUNCTION cleanup_expired_otps()
RETURNS INTEGER AS $$
DECLARE deleted_count INTEGER;
BEGIN
  DELETE FROM otp_tokens WHERE expires_at < NOW() - INTERVAL '1 hour';
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- ─── FUNCTION: User issue stats ─────────────────────────────────────────────
CREATE OR REPLACE FUNCTION get_user_stats(p_user_id UUID)
RETURNS TABLE(
  total_reports BIGINT,
  resolved_reports BIGINT,
  open_reports BIGINT,
  total_votes_given BIGINT,
  avg_issue_rating NUMERIC
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    COUNT(DISTINCT i.id)::BIGINT,
    COUNT(DISTINCT i.id) FILTER (WHERE i.status = 'resolved')::BIGINT,
    COUNT(DISTINCT i.id) FILTER (WHERE i.status = 'open')::BIGINT,
    COUNT(DISTINCT v.id)::BIGINT,
    ROUND(AVG(i.citizen_rating) FILTER (WHERE i.citizen_rating IS NOT NULL), 1)
  FROM users u
  LEFT JOIN issues i ON i.reported_by = u.id
  LEFT JOIN issue_votes v ON v.user_id = u.id
  WHERE u.id = p_user_id;
END;
$$ LANGUAGE plpgsql;

-- ─── TRIGGER: Log issue creation to activity ────────────────────────────────
-- (already handled in application code, but this is a fallback)
CREATE OR REPLACE FUNCTION log_issue_status_change()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    INSERT INTO issue_activity (issue_id, action, old_value, new_value, note, is_public, actor_name)
    VALUES (NEW.id, 'status_changed', OLD.status, NEW.status, 
            'Automatic status change logged', TRUE, 'System');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Only create trigger if it doesn't exist (safe re-run)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'log_issue_status_change_trigger'
  ) THEN
    CREATE TRIGGER log_issue_status_change_trigger
      AFTER UPDATE ON issues
      FOR EACH ROW
      WHEN (OLD.status IS DISTINCT FROM NEW.status)
      EXECUTE FUNCTION log_issue_status_change();
  END IF;
END $$;

SELECT 'NagarSeva auth-extended schema installed successfully!' AS message;
